# Импортируем необходимые библиотеки:

import collections
from collections import defaultdict #импортируем словарь для спам и неспам слов
import re #для очистки текстов
import pandas as pd #для работы с обучающей выборкой
import numpy as np
import math

# Задаем переменные:

SPAM = 1
NOT_SPAM = 0

pA = 0.0 #вероятность встретить спам
pNotA = 0.0 #вероятность не встретить спам
YesSpam = {} #словарь для спамслов
NoSpam = {} #словарь для неспам-слов

allword={} # словарь для всех слов в обоих выборках

class_freqs = collections.defaultdict(int) #словарь для количества классов
class_freqs[SPAM]=0
class_freqs[NOT_SPAM]=0

# Зададим функцию для доступа к словарю по параметру:
def get_dict(label):
    if (label == 1):
        return YesSpam
    else:
        return NoSpam

#В переменную запишем лямбда-функцию для очистки обучающей выборки от всех лишних символов:

remove_non_alphabets =lambda x: re.sub(r'[^a-zA-Z]',' ',x)

# Формируем словари для спам-слов YesSpam и неспам-слов NoSpam:

def calculate_word_frequencies(body, label):
    
    text = body.lower()

    list_of_str = re.findall(r'\b[a-z]+\b', text) #зададим ограничение на длину слова, чтобы исключить предлоги и тп
    
    dict1 = get_dict(label)
    
    for word in list_of_str:
        if (word in dict1):
            dict1[word] = dict1[word] + 1
        else:
            dict1[word] = 1
    
    for word in list_of_str:
        if word in allword.keys():
            allword[word] += 1
        else:
            allword[word] = 1
    return

# Зададим обучающую функцию:

def train(train_data):
    global YesSpam
    global NotSpam 
    global pA 
    global pNotA 
    
    YesSpam = {}
    NotSpam = {}
    
    for data in train_data:
        calculate_word_frequencies(data[0], data[1])
        class_freqs[data[1]] += 1
    
    pA = class_freqs[SPAM]/(class_freqs[SPAM] + class_freqs[NOT_SPAM])
    pNotA = class_freqs[NOT_SPAM]/(class_freqs[SPAM] + class_freqs[NOT_SPAM]) 

    return

#первоначальный тренировочный набор данных:

#train_data = [  
#    ['Купите новое чистящее средство', SPAM],   
#    ['Купи мою новую книгу', SPAM],  
#    ['Подари себе новый телефон', SPAM],
#    ['Добро пожаловать и купите новый телевизор', SPAM],
#    ['Привет давно не виделись', NOT_SPAM], 
#    ['Довезем до аэропорта из пригорода всего за 399 рублей', SPAM], 
#    ['Добро пожаловать в Мой Круг', NOT_SPAM],  
#    ['Я все еще жду документы', NOT_SPAM],  
#    ['Приглашаем на конференцию Data Science', NOT_SPAM],
#    ['Потерял твой телефон напомни', NOT_SPAM],
#    ['Порадуй своего питомца новым костюмом', SPAM]
#] 

#Код для отображения всех результатов ячеек в одном аутпуте для отладки

#from IPython.core.interactiveshell import InteractiveShell
#InteractiveShell.ast_node_interactivity = "all"

#init_train()

#YesSpam
#NoSpam

#class_freqs

#print('Spam words qty:', len(YesSpam),'NotSpam words qty:', len(NoSpam),'\n', sep='\n')
#print('pA:', pA, 'pNotA:', pNotA, sep='\n')

# Считаем вероятности спама и не спама для слова:

def calculate_P_Bi_A(word, label): 
    dict1 = get_dict(label)
# Вероятность того, что слово является спамом:
# в числителе число вхождений слова в спам словарь
# в знаменателе число слов в словарях спам и не спам

    pt = 0
    if (word in dict1):
        pt = np.log((1+dict1[word])/(len(dict1)+sum(dict1.values())))
    else:
        pt = np.log(1/sum(allword.values()))
    return pt

# Считаем вероятности для строки:

def calculate_P_B_A(text, label):
    text_low = text.lower()
    words = re.findall(r'\b[a-z]+\b',text_low)
    
    result = 0
    
    for word in words:
        result += calculate_P_Bi_A(word, label)
    
    return result

# Реализация классификатора:

def classify(email):
   
    p_A_B = np.log(pA) + calculate_P_B_A(email, SPAM)
    p_A_not_B = np.log(pNotA) + calculate_P_B_A(email, NOT_SPAM)
#    print('prob_spam', p_A_B)
#    print('prob_not_spam', p_A_not_B)
   
    if p_A_B > p_A_not_B:
        return 'SPAM'
    else:
        return 'NOT SPAM'
#    return p_A_B > p_A_not_B

def init_train():

    df = pd.read_csv('spam_or_not_spam.csv')
# 0 - 2500 not spam 
# 1 - 500 is spam
    df.dropna(inplace=True)
    df['email'] = df['email'].apply(remove_non_alphabets)
    
    train_data = []
    
    df1 = df[df.label == 1]
    df0 = df[df.label == 0]

    for index, row in df1.iterrows():
        train_data.append([row['email'], SPAM])

    for index, row in df0.iterrows():
        train_data.append([row['email'], NOT_SPAM])
    
    train(train_data)
