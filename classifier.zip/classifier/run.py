# classifier/run.py
from application import app
from spam_classifier import init_train

init_train()